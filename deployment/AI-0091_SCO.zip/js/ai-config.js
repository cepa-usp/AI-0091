// Variáveis do AI_Loader
var flashvars = {};
flashvars.ai = "swf/AI-0091.swf";
flashvars.width = "600";
flashvars.height = "386";

// Parâmetros do player (Flash)
var params = {};
params.menu = "false";
params.scale = "showall";

// Atributos da tag HTML que contém o SWF
var attributes = {};
attributes.id = "ai";
attributes.align = "middle";
